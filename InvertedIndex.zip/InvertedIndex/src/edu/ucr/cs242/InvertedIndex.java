package edu.ucr.cs242;

import java.io.IOException;

import org.apache.hadoop.conf.Configuration;
import org.apache.hadoop.fs.FileSystem;
import org.apache.hadoop.fs.Path;
import org.apache.hadoop.io.NullWritable;
import org.apache.hadoop.io.Text;
import org.apache.hadoop.mapreduce.Job;
import org.apache.hadoop.mapreduce.lib.input.FileInputFormat;
import org.apache.hadoop.mapreduce.lib.output.FileOutputFormat;


public class InvertedIndex {

    public static void main(String[] args) throws Exception {
        Configuration conf = new Configuration();
        /**
         * start tag and end tag added
         */
        conf.set("xmlinput.start", "<DOC>");
        conf.set("xmlinput.end", "</DOC>");
        Job job = Job.getInstance(conf, "Inverted Index");
        job.setJarByClass(InvertedIndex.class);

        /**
         *  Code can be inserted to do the Data Munging
         *  That can include removing stop words, punctuation, etc.
         */

        
        deleteFolder(conf, args[1]);

        myMapReduceTask(job, args[0], args[1]);
    }

    public static void deleteFolder(Configuration conf, String folderPath) throws IOException {
        // Delete the Folder
        FileSystem fs = FileSystem.get(conf);
        Path path = new Path(folderPath);
        if (fs.exists(path)) {
            fs.delete(path, true);
        }
    }

    public static void myMapReduceTask(Job job, String inputPath, String outputPath) throws
            IllegalArgumentException,
            IOException,
            ClassNotFoundException,
            InterruptedException {

        // Set Mapper Class
        job.setMapperClass(InvertedIndexMapper.class);

        // Set Mapper Output Types
        job.setMapOutputKeyClass(Text.class);
        job.setMapOutputValueClass(Text.class);

        // Set Combiner Class
        //job.setCombinerClass(InvertedIndexReducer.class); 

        // Set Reducer Class
       job.setReducerClass(InvertedIndexReducer.class);
        
        //input files are of xml format  
        job.setInputFormatClass(XmlInputFormat.class);

        // Set the Reducer Output Types
        job.setOutputKeyClass(Text.class);
        job.setOutputValueClass(NullWritable.class);

        // Specify input and output Directories


        //TODO: validate the next two lines
        FileInputFormat.addInputPath(job, new Path(inputPath));
        FileOutputFormat.setOutputPath(job, new Path(outputPath));

        // Wait condition for the Mapper and Reducer Class to finish their execution
        System.exit(!job.waitForCompletion(true) ? 0 : 1);
    }
}
package edu.ucr.cs242.common.util.shekhargulati;


public class UrlCleanerException extends RuntimeException {

    public UrlCleanerException(Throwable cause) {
        super(cause);
    }
}
package edu.ucr.cs242;

import java.io.IOException;
import java.util.HashSet;
import java.util.Set;
import org.apache.hadoop.io.NullWritable;
import org.apache.hadoop.io.Text;
import org.apache.hadoop.mapreduce.Reducer;


import org.json.simple.JSONObject;





public class InvertedIndexReducer extends Reducer<Text, Text, Text, NullWritable> {
    public void reduce(Text keyIndexWord, Iterable<Text> valuesDocNoAndPos, Context context)
            throws IOException, InterruptedException {
        // This set will store the names of the document where the key had word(key) appeared
        Set<String> docNoAndPos = new HashSet<>();

        // on reducer side
        //  String[] e = s.split(".");
        //  e[0]
        //  e[1]
       int len=0;
        for (Text valueDocNoAndPos : valuesDocNoAndPos) {
        	len=len+1;
            // Duplicates not included
            String[] splitValueDocNoAndPos = valueDocNoAndPos.toString().split("~");
            docNoAndPos.add(splitValueDocNoAndPos[0]);
        }
        
       
      
        String indexString = "";

        // Read the set one by one and concat to a string
     
      
       
        for (String valueDocNoAndPos : docNoAndPos) {
            indexString = new String(indexString.concat(valueDocNoAndPos.concat(" ")));
        	
        	
        }
        
        /**
         * Assign the output to a Json Object 
         */
        JSONObject jsn = new JSONObject();
        
        	
        try {
			jsn.put("KEYWORD",keyIndexWord.toString());
			jsn.put("DOCIDS",indexString);
			
		} 
        
        catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
       // context.write(keyIndexWord, new Text(indexString));
        context.write(new Text(jsn.toString()), null); // Json oputput to file
    }
}